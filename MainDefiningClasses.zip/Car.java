public class Car {
    public String brand;
    public String model;
    public int horsePower;
}
