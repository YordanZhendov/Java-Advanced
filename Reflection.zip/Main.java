import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {

        Class reflectionClass = Reflection.class;
        System.out.println("class " + reflectionClass.getName());

        Class superclassReflection = Reflection.class.getSuperclass();
        System.out.println("class "+ superclassReflection.getName());

        Class [] interfaces = Reflection.class.getInterfaces();
        for (Class anInterface : interfaces) {
            System.out.println("interface "+anInterface.getName());
        }

        Object objectRef = reflectionClass.getDeclaredConstructor().newInstance();
        System.out.println(objectRef);
    }
}
