import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String rankPower = scanner.nextLine();
        String suitPower = scanner.nextLine();


        Card carDeck = new Card();
        carDeck.setRankPower(rankPower);
        carDeck.setSuitPower(suitPower);

        System.out.printf("Card name: %s of %s; Card power: %d",rankPower,suitPower,carDeck.getPower());
    }
}
