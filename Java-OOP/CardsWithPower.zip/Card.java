public class Card {
    private int rankPower;
    private int suitPower;

    public Card() {

    }

    public int getPower() {
        return rankPower+suitPower;
    }

    public void setRankPower(String rankPower) {
        int count=2;
        for (Enumeration value : Enumeration.values()) {
            if(rankPower.equals(value.name())){
                break;
            }
            count++;
        }
        this.rankPower=count;
    }


    public void setSuitPower(String suitPower) {
        int suitP=0;
        switch (suitPower) {
            case "CLUBS":
                suitP=0;
                break;
            case "DIAMONDS":
                suitP=13;
                break;
            case "HEARTS":
                suitP=26;
                break;
            case "SPADES":
                suitP=39;
                break;
        }
        this.suitPower = suitP;
    }
}
