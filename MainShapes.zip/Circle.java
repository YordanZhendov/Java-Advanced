public class Circle extends Shape{
    private Double radius;

    public Circle(Double radius) {
        this.radius = radius;
    }

    public final Double getRadius() {
        return radius;
    }

    public final void setRadius(Double radius) {
        this.radius = radius;
    }

    @Override
    public void calculatePerimeter() {

    }

    @Override
    public void calculateArea() {

    }
}
