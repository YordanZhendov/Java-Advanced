public class BankAccount {
    private static int count=1;

    private int id;
    private double balance;
    private static double interestRate = 0.02;

    public BankAccount(){
        this.id=count;
        count++;
    }

    public int getId(){
        return this.id;
    }

    public static void setInterestRate(double interestRate){
        BankAccount.interestRate=interestRate;
    }
    public double getInterest(int year){
        return year*interestRate*balance;
    }
    public void deposit(double amount){
        this.balance+=amount;
    }



}
