import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input;

        Map<Integer,BankAccount> people=new LinkedHashMap<>();
        while (!"End".equals(input = scanner.nextLine())){


            String[] tokens = input.split("\\s+");

            String output;
            switch (tokens[0]) {
                case "Create":
                    BankAccount bankAccount = new BankAccount();
                    people.putIfAbsent(bankAccount.getId(),bankAccount);
                    System.out.printf("Account ID%d created%n", bankAccount.getId());
                    break;
                case "Deposit":
                    int id= Integer.parseInt(tokens[1]);
                    double amount=Integer.parseInt(tokens[2]);
                    if(!people.containsKey(id)){
                        System.out.println("Account does not exist");
                    }else {
                        people.get(id).deposit(amount);
                        System.out.printf("Deposited %.0f to ID%d%n",amount,id);
                    }
                    break;
                case "GetInterest":
                    int idInterest= Integer.parseInt(tokens[1]);
                    int interestPerYear=Integer.parseInt(tokens[2]);
                    if(!people.containsKey(idInterest)){
                        System.out.println("Account does not exist");
                    }else {

                        double interest = people.get(idInterest).getInterest(interestPerYear);
                        System.out.printf("%.2f%n",interest);
                    }
                    break;

                case "SetInterest":
                    double rate= Double.parseDouble(tokens[1]);
                    BankAccount.setInterestRate(rate);
                    break;
            }
        }
    }
}
